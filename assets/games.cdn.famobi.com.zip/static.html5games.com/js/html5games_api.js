!(function(a) {
	'use strict';

	var detection = (function() {
		var mod = { is: {} },
			d,
			ua = navigator.userAgent;
		mod.detect = {
			html5: function() {
				return document.createElement('canvas').getContext !== undefined;
			},
			touch: function() {
				var supportsTouch = 'ontouchstart' in window || navigator.msMaxTouchPoints;
				return !!supportsTouch;
			},
			android: function() {
				return !!ua.match(/Android/i);
			},
			ios: function() {
				return !!ua.match(/iPhone|iPad|iPod/i);
			},
			ios7: function() {
				return mod.detect.ios && ua.match(/version\/7\./i);
			},
			bb10: function() {
				return !!ua.match(/BB10/i);
			},
			windows: function() {
				return !!ua.match(/Windows/i);
			},
			webkitVersion: function() {
				var regex = new RegExp(/AppleWebKit\/([\d.]+)/),
					result = regex.exec(ua),
					webkitVersion = result === null ? false : parseFloat(result[1]);
				return webkitVersion;
			},
			androidStockBrowser: function() {
				if (mod.is.android && mod.is.webkitVersion && mod.is.webkitVersion < 537) {
					return true;
				}
				return false;
			},
			standalone: function() {
				return !!window.navigator.standalone;
			},
			smartphone: function() {
				return ua.match(/Android.*Mobile|iPhone|IEMobile|WPDesktop|BB10/i) ? true : false;
			},
			tablet: function() {
				// Android smartphones have the combination Android...Mobile, tablets only Android
				var androidTablet = mod.is.android && !mod.is.smartphone,
					iPad = ua.match(/iPad/i) ? true : false;
				return androidTablet || iPad;
			},
			pc: function() {
				return !mod.is.smartphone && !mod.is.tablet;
			},
			phantom: function() {
				return !!(window.callPhantom || ua.match(/PhantomJS/));
			},
			iframe: function() {
				return window.self != window.top;
			}
		};

		for (d in mod.detect) {
			if (typeof mod.detect[d] === 'function') {
				mod.is[d] = mod.detect[d]();
			}
		}

		return mod;
	})();

	function wait(ms) {
		return new Promise(function(resolve) {
			setTimeout(resolve, ms);
		});
	}

	function getQueryParams(qs) {
		qs = qs.split('+').join(' ');

		var params = {},
			tokens,
			re = /[?&]?([^=]+)=([^&]*)/g;

		while ((tokens = re.exec(qs))) {
			params[decodeURIComponent(tokens[1])] = decodeURIComponent(tokens[2]);
		}

		return params;
	}

	var socketURI = '';
	var queryParams = getQueryParams(document.location.search);

	if (document.location.href.indexOf('localhost') !== -1) {
		socketURI = 'ws://localhost:3001/sock';
	} else if (document.location.href.indexOf('staging') !== -1) {
		socketURI = 'wss://staging.api.html5games.com/sock';
	} else {
		socketURI = 'wss://api.html5games.com/sock';
	}

	var self = this;
	var fn = function() {};
	var events = {
		'leaderboard received': fn
	};
	var event = {
		on: function(name, handler) {
			if (typeof handler === 'function') {
				events[name] = handler;
			}
		},
		once: function(name, handler) {
			if (typeof handler === 'function') {
				handler.fireOnce = true;
				events[name] = handler;
			}
		},
		fire: function(name, data) {
			if (name in events) {
				events[name].call(self, data);
				if (events[name].fireOnce) {
					events[name] = fn;
				}
			}
		}
	};
	var session = {};
	var sessionData = {
		id: '',
		beg: 0,
		uid: '',
		app: ''
	};
	var canonical = document.querySelector('link[rel="canonical"]');
	if (canonical && canonical.getAttribute('href')) {
		sessionData.uri = canonical.getAttribute('href');
	} else {
		sessionData.uri = document.location.protocol + '//' + document.location.host;
	}
	sessionData.path = document.location.pathname;
	if ('original_ref' in queryParams) {
		sessionData.ref = decodeURIComponent(queryParams['original_ref']) || document.referrer;
	} else {
		sessionData.ref = document.referrer || '';
	}
	sessionData.lang = getNavigatorLocale() || '';
	sessionData.res = screen.width + 'x' + screen.height;
	sessionData.dc = detection.is.pc
		? 'desktop'
		: detection.is.tablet
			? 'tablet'
			: detection.is.smartphone
				? 'mobile'
				: 'other';
	sessionData.os = detection.is.windows
		? 'windows'
		: detection.is.android
			? 'android'
			: detection.is.ios
				? 'ios'
				: 'other';
	sessionData.ifr = detection.is.iframe ? '1' : '0';

	var liveData = {
		err: 0,
		dur: 0,
		sess: ''
	};
	var keepaliveTimeout = 60;
	var keepaliveTimeoutId = 0;
	var pageVisibility = 1;
	var hidden, visibilityChange;
	if (typeof document.hidden !== 'undefined') {
		// Opera 12.10 and Firefox 18 and later support
		hidden = 'hidden';
		visibilityChange = 'visibilitychange';
	} else if (typeof document.msHidden !== 'undefined') {
		hidden = 'msHidden';
		visibilityChange = 'msvisibilitychange';
	} else if (typeof document.webkitHidden !== 'undefined') {
		hidden = 'webkitHidden';
		visibilityChange = 'webkitvisibilitychange';
	}

	function handleVisibilityChange() {
		if (document[hidden] || document[visibilityChange] === 'hidden') {
			pageVisibility = 0;
		} else {
			pageVisibility = 1;
		}
	}
	// Handle page visibility change
	document.addEventListener(visibilityChange, handleVisibilityChange, false);

	handleVisibilityChange();

	function initSession(appName) {
		sessionData.app = appName.toLowerCase().replace(/\s/g, '-') || 'unknown';
		try {
			sessionData.uid = window.localStorage.getItem('html5games_uid') || '';
			sessionData.d0 = window.localStorage.getItem(sessionData.app + ':d0') || 0;
			// day z: day of the last return
			sessionData.dz = window.localStorage.getItem(sessionData.app + ':dz') || 0;

			if (sessionData.d0 === 0) {
				sessionData.ret = 0;
			}
		} catch (ex) {
			// eslint-disable-next-line no-console
			console.log('something went wrong, start a new session', ex);
		}

		!(function() {
			var ws;
			var retryCount = 0;

			if (!session.ws) {
				session.sd = JSON.parse(JSON.stringify(sessionData));
				session.ld = JSON.parse(JSON.stringify(liveData));
				session.leaderboard = {
					winner: {},
					scores: [],
					ttl: -1
				};
				session.apptastic = [];
			}
			session.ws = ws;

			!(function connect() {
				// delay reconnect, the page is not visible
				if (pageVisibility === 0) {
					return setTimeout(connect, Math.min(60e3, retryCount * 2e3));
				}

				session.ws = ws = new WebSocket(socketURI + '/v0.16/sessions');

				ws.onopen = function open() {};

				ws.onclose = function close() {
					// panic mode! stop the interval
					if (keepaliveTimeoutId) {
						clearTimeout(keepaliveTimeoutId);
					}
					setTimeout(connect, Math.min(60e3, retryCount * 4e3));
				};

				ws.onmessage = function incoming(frame) {
					var msg = JSON.parse(frame.data);
					switch (msg.type) {
					case 'bye':
						session.sd.id = sessionData.id = '';
						session.sd.beg = sessionData.beg = '';
						break;
					case 'greeting':
						if (sessionData.uid === '') {
							sessionData.uid = msg.uid;
						}
						if (sessionData.d0 === 0 || sessionData.dz === 0) {
							sessionData.d0 = sessionData.dz = msg.beg;
						} else {
							var now = msg.beg - (msg.beg % 86400e3);
							var last_seen = sessionData.dz - (sessionData.dz % 86400e3);
							sessionData.ret = Math.floor(
								(now - last_seen) / 1e3 / 60 / 60 / 24
							);
							sessionData.dz = msg.beg;
							if (sessionData.ret < 1) {
								sessionData.ret = undefined;
							}
						}
						try {
							window.localStorage.setItem('html5games_uid', sessionData.uid);
							window.localStorage.setItem(
								sessionData.app + ':d0',
								sessionData.d0
							);
							window.localStorage.setItem(
								sessionData.app + ':dz',
								sessionData.dz
							);
						} catch (ex) {
							// eslint-disable-next-line no-console
							console.log('localStorage is full or not supported', ex);
						}
						liveData.sess = sessionData.id = sessionData.id
							? sessionData.id
							: sessionData.uid + '.' + sessionData.app + '.' + msg.beg;
						sessionData.beg = sessionData.beg ? sessionData.beg : Number(msg.beg);
						session.sd.id = sessionData.id;
						session.sd.beg = sessionData.beg;
						session.sd.uid = sessionData.uid;
						if (typeof sessionData.ret !== 'undefined') {
							session.sd.d0 = parseInt(sessionData.d0, 10);
							session.sd.ret = sessionData.ret;
						} else {
							session.sd.d0 = undefined;
							session.sd.ret = undefined;
						}
						session.sd.dz = undefined;
						session.ld.sess = liveData.sess;
						ws.send(
							JSON.stringify({
								type: 'sd',
								payload: session.sd
							})
						);
						keepaliveSession();
						break;
					case 'apptastic':
						session.apptastic = msg.payload;
						break;
					case 'leaderboard':
						session.leaderboard = msg.payload;
						event.fire('leaderboard received', session.leaderboard);
						break;
					}
				};

				retryCount++;
			})();

			function keepaliveSession() {
				keepaliveTimeoutId = setTimeout(function() {
					if (
						pageVisibility === 1 &&
						(typeof document.hasFocus === 'undefined' || document.hasFocus())
					) {
						session.ld.dur += keepaliveTimeout;

						if (session.ld.dur % keepaliveTimeout === 0) {
							ws.send(
								JSON.stringify({
									type: 'ld',
									payload: session.ld
								})
							);
						}
					}

					// check again after timeout
					keepaliveSession();
				}, keepaliveTimeout * 1e3);
			}
		})();
	}

	function submitScore(opts) {
		var score = opts.score;
		return new Promise(function(resolve, reject) {
			var ws = session.ws;
			if (!ws || ws.readyState !== 1) {
				return reject('No active session');
			}
			// bind event handler for leaderboard response
			event.once('leaderboard received', resolve);
			// send score
			ws.send(
				JSON.stringify({
					type: 'fn',
					payload: {
						fn: 'submitScore',
						score: score,
						app: sessionData.app,
						uid: sessionData.uid
					}
				})
			);
		});
	}

	function updateProfile(data) {
		var nick = data.nick;
		return new Promise(function(resolve, reject) {
			var ws = session.ws;
			if (!ws || ws.readyState !== 1) {
				return reject('No active session');
			}
			// send data
			ws.send(
				JSON.stringify({
					type: 'fn',
					payload: {
						fn: 'updateProfile',
						nick: nick,
						uid: sessionData.uid
					}
				})
			);
		});
	}

	function getNavigatorLocale() {
		var language = '';

		if (navigator.languages) {
			language = navigator.languages[0];
		} else if (navigator.language) {
			language = navigator.language;
		} else if (navigator.userLanguage) {
			language = navigator.userLanguage;
		} else if (navigator.browserLanguage) {
			language = navigator.browserLanguage;
		}

		return language;
	}

	function getNavigatorLanguage() {
		return getNavigatorLocale().substr(0, 2);
	}

	a.html5games_api = {
		init: initSession,
		submitScore: submitScore,
		updateProfile: updateProfile
	};
})(window);
